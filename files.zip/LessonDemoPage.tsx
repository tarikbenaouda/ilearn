import { useState } from 'react'
import { Lesson } from '@/components/Lesson'
import { percentagesLesson, linearEqLesson } from '@/data/demoLessons'
import { Button } from '@/components/ui/button'

const lessons = [percentagesLesson, linearEqLesson]

export function LessonDemoPage() {
  const [activeIdx, setActiveIdx] = useState(0)
  const lesson = lessons[activeIdx]

  return (
    <div className="min-h-screen bg-background">
      {/* Minimal navbar / switcher */}
      <header className="h-12 border-b border-border flex items-center px-6 gap-3 sticky top-0 z-10 bg-background/95 backdrop-blur-sm">
        <span className="text-sm text-muted-foreground">اختر درساً:</span>
        {lessons.map((l, i) => (
          <Button
            key={l.conceptId}
            variant={activeIdx === i ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveIdx(i)}
            className={activeIdx === i ? 'bg-violet-600 hover:bg-violet-700 text-white' : ''}
          >
            {l.title}
          </Button>
        ))}
      </header>

      <Lesson
        key={lesson.conceptId}
        data={lesson}
        onComplete={(score) => console.log('score:', score)}
      >
        <Lesson.Problem />
        <Lesson.Hints />
        <Lesson.Theory />
        <Lesson.Task />
        <Lesson.Feedback />
      </Lesson>
    </div>
  )
}
