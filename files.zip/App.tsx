// Add this import at the top of your App.tsx:
// import { LessonDemoPage } from '@/pages/LessonDemoPage'

// Add this route inside your <Routes>:
// <Route path="/demo" element={<LessonDemoPage />} />

// Full minimal App.tsx if you don't have one yet:
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { LessonDemoPage } from '@/pages/LessonDemoPage'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/demo" element={<LessonDemoPage />} />
      </Routes>
    </BrowserRouter>
  )
}
